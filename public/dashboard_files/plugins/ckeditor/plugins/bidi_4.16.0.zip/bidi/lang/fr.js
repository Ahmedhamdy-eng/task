/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'bidi', 'fr', {
	ltr: 'Direction du texte de la gauche vers la droite',
	rtl: 'Direction du texte de la droite vers la gauche'
} );
